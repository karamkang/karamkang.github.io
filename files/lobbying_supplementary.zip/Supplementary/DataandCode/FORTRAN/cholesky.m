clear;
n = 22;

% cholesky decomposition of the variace-covariance matrix using the built-in matlab function 
m = csvread('var_matrices.csv');
ehessian = m(1:n,:);
ihessian = m((n+1):2*n,:);
varscore = m((2*n+1):3*n,:);
std = ihessian*chol(varscore,'lower');

% save the standard error matrix (cholesky decomposition) into a file
fid = fopen('stdmat.txt','wt');
for i = 1:n
    for j = 1:n
        fprintf(fid,'%.15g\n',std(i,j));
    end
end
fclose(fid);