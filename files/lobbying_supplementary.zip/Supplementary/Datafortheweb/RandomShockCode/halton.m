function [r,seed2] = halton(dnum,n,step,seed,leap,base)

seed(1:dnum) = floor(seed(1:dnum));
leap(1:dnum) = floor(leap(1:dnum));
base(1:dnum) = floor(base(1:dnum));
r(1:dnum,1:n) = 0.0;

for i = 1: dnum
    seed2(1:n) = (seed(i)+step*leap(i)):leap(i):(seed(i)+(step+n-1)*leap(i));
    base_inv = 1.0 / base(i);
    while (any(seed2~=0))
        digit(1:n) = mod(seed2(1:n),base(i));
        r(i,1:n) = r(i,1:n) + digit(1:n) * base_inv;
        base_inv = base_inv / base(i);
        seed2(1:n) = floor(seed2(1:n)/base(i));
    end
end
r = r';