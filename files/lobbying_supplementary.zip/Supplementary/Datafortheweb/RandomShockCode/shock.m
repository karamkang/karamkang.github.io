clear;
dnum = 5;           % policy shock + values shocks (# of palyers)
dlt = 100;          % deterministic shocks to be disgarded
nsim = 50000;       % per observation shocks
n = nsim+dlt;
num = 530;          % sample size

fout1 = fopen('simshock1.txt','wt');
fout2 = fopen('simshock2.txt','wt');
fout3 = fopen('simshock3.txt','wt');
fout4 = fopen('simshock4.txt','wt');
fout5 = fopen('simshock5.txt','wt');

step = zeros(dnum,1);
leap = ones(dnum,1);
seed = zeros(dnum,1);
for i = 1:num
    disp(i);
    base = [2 3 5 7 11];
    [r seed] = halton(dnum,n,step,seed,leap,base); 
    shocks = zeros(n-dlt,dnum);
    shocks(:,1) = 2*r((dlt+1):n,1) - 1;
    shocks(:,2:dnum) = norminv(r((dlt+1):n,2:dnum),0,1);
    for j = 1:nsim
        fprintf(fout1,'%f\n',shocks(j,1));
        fprintf(fout2,'%f\n',shocks(j,2));
        fprintf(fout3,'%f\n',shocks(j,3));
        fprintf(fout4,'%f\n',shocks(j,4));
        fprintf(fout5,'%f\n',shocks(j,5));
    end
end

fclose(fout1);
fclose(fout2);
fclose(fout3);
fclose(fout4);
fclose(fout5);

clear;
dnum = 1;
dlt = 20;
nsim = 5000;
np = 24;
n = nsim*np+dlt;
step = zeros(dnum,1);
leap = ones(dnum,1);
seed = zeros(dnum,1);
base = 19;
r = halton(dnum,n,step,seed,leap,base);
shocks = norminv(r((dlt+1):n,:),0,1);

mout = fopen('parshock.txt','wt');
for i = 1:(nsim*np)
    fprintf(mout,'%24.16f\n',shocks(i));
end
fclose(mout);